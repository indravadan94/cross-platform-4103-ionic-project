import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Vibration } from '@ionic-native/vibration';
import { InAppBrowser } from '@ionic-native/in-app-browser';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController, public vibration:Vibration, public iab: InAppBrowser) {

  }

  clickVibration(){
    this.vibration.vibrate(3000);
  }
  openUrl(){
    const browser = this.iab.create('https://google.com/','_self');
    browser.show();
  }

}
