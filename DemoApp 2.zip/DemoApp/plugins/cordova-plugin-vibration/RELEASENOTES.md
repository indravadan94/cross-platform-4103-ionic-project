### 3.0.1 (Dec 27, 2017)
* [CB-13711](https://issues.apache.org/jira/browse/CB-13711) Fix to allow 3.0.0 version install (#63)

